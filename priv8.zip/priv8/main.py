# usr/bin/python3

import requests
import json
import threading
import os
import socket
from lib.bruteforce.wpbf import *
from lib.bruteforce.opencart import *
from lib.bruteforce.massBf import *
# Colors
from colorama import Fore, Style, init

session = requests.Session()
requests.packages.urllib3.disable_warnings()
# Inisialisasi colorama
init(autoreset=True)
def colors(teks, kode_warna):
    return f"{kode_warna}{teks}{Fore.LIGHTGREEN_EX}{Style.RESET_ALL}"

# Typographpy
space = " "*10

reset = Style.RESET_ALL
yellow = Fore.LIGHTYELLOW_EX
magenta = Fore.LIGHTMAGENTA_EX
red = Fore.RED
cyan = Fore.LIGHTCYAN_EX
green = Fore.LIGHTGREEN_EX
blue = Fore.LIGHTBLUE_EX
# login
def login():
    password = input(colors("[+]Input Key # ", Fore.LIGHTMAGENTA_EX))
    Pass = "Black"
    if  password == Pass:
        print("Hay")
    else:
        exit(1)

#================= MENU ==========================#

def menu():
    dash = "─"*75
    spaceA = " "*28
    spaceB = " "*4
    banner = f"""
{magenta}╔{dash}╗    
{magenta}│{spaceA}{green}BLACK SPACE TOOLS{space}{space}{space}{magenta}│
{magenta}╚{dash}╝\n
{magenta}[{cyan}1{magenta}] {reset}Wordpress Brute Force
{magenta}[{cyan}2{magenta}] {reset}Mass Brute Force Wordpress
    """
    print(banner)

if __name__ == "__main__":
    menu()
    cmd = input(f"{blue}┌──({red}root@localhost{blue})-[{reset}/root/BlackSpace{blue}]\n{blue}└─{red}#{reset} ")
    if cmd == "1":
        run()
    if cmd == "2":
        massWp()
    
    
    
    
    
    
    