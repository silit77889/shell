import dns.resolver

def find_subdomains(domain):
    subdomains = []

    # Mencari rekam subdomain dengan menggunakan DNS
    try:
        answers = dns.resolver.resolve(domain, 'A')
        for answer in answers:
            subdomains.append(answer.target)
    except dns.resolver.NXDOMAIN:
        print(f'Tidak ada subdomain ditemukan untuk {domain}')

    return subdomains

# Contoh penggunaan
domain_to_search = "upr.ac.id"
subdomains = find_subdomains(domain_to_search)

if subdomains:
    print(f"Subdomains untuk {domain_to_search}: {', '.join(subdomains)}")
