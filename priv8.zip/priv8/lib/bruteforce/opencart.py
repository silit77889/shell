import requests, re, threading, time, json, os
from colorama import Fore, Style, init
import urllib.parse
import urllib.request
import re
init()
reset = Style.RESET_ALL
yellow = Fore.LIGHTYELLOW_EX
magenta = Fore.LIGHTMAGENTA_EX
red = Fore.RED
cyan = Fore.LIGHTCYAN_EX
green = Fore.LIGHTGREEN_EX
blue = Fore.LIGHTBLUE_EX
def r_file(file_name):
    try:
        with open(file_name, "r") as file:
            passwords = file.read().splitlines()
            return passwords
    except Exception as e:
        print(f"{green}[{red}-{green}]{reset} Failed To Load File {file_name}: {str(e)}")
        return []
